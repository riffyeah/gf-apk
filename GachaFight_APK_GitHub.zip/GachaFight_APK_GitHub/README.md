# GACHA & FIGHT Android APK

This project wraps the supplied HTML game in an Android WebView. The original game file is `app/src/main/assets/index.html`.

## Build APK with GitHub Actions
1. Create a new GitHub repository.
2. Upload all files and folders from this project to the repository root.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and press **Run workflow** (or wait for the first push build).
5. Open the completed workflow run, scroll to **Artifacts**, and download **Gacha-Fight-APK**.
6. Extract the ZIP and install `app-debug.apk` on Android.

The APK is a debug build, suitable for testing and sideloading. It is not a Play Store release build.
